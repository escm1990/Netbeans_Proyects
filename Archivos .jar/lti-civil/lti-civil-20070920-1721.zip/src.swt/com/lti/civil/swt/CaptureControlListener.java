/*
 * Created on Jun 1, 2005
 */
package com.lti.civil.swt;

/**
 * 
 * @author Ken Larson
 */
public interface CaptureControlListener
{
	public void onSnap(com.lti.civil.Image image);

}
