package com.lti.swtutils.swt_rwt;

/**
 * 
 * @author Ken Larson
 *
 */
public interface MessageBoxResultListener
{
	public void onMessageBoxResult(int result);
}
