package com.lti.swtutils.image;

import org.eclipse.swt.graphics.Image;

/**
 * 
 * @author Ken Larson
 *
 */
public interface ImageProxy
{

	public Image getImage();
}
