package com.lti.swtutils.image;

/**
 * 
 * @author Ken Larson
 *
 */
public interface ImageSizeChangedListener
{

	public void onImageSizeChanged(ImageControl sender);
}
