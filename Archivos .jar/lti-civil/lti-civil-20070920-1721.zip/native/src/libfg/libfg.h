/** \mainpage libfg - Framegrabber Library
 *
 *  \section intro Introduction
 *
 *  \section capture Capturing Video
 */

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */

#include "capture.h"
#include "frame.h"
    
#ifdef __cplusplus__
}
#endif /* __cplusplus__ */
