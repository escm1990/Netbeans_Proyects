/*
 * Created on May 25, 2005
 */
package com.lti.civil;

/**
 * 
 * @author Ken Larson
 */
public interface CaptureDeviceInfo
{
	public String getDeviceID();
	public String getDescription();
}
