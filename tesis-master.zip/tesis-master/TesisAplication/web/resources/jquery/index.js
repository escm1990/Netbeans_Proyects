/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    
  //$("#map").gMap();
  
  $('.datatables').DataTable();
  
});
